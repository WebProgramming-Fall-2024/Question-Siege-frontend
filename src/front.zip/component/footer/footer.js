export function Footer(){
    return (
        <nav className="navbar fixed-bottom navbar-expand-lg navbar-light bg-light py-2 d-flex justify-content-end px-4">
            دانشگاه شریف
        </nav>

    )
}