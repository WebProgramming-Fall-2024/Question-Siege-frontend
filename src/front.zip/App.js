import logo from './logo.svg';
import {Login_signup} from "./component/login_signup/login_signup";
import {Main} from "./component/Main/Main";
import 'bootstrap/dist/css/bootstrap.min.css'
import $ from 'jquery'
import 'bootstrap/dist/js/bootstrap.min.js'
import './lib/fonts/icomoon/style.css'
import './lib/global.css'
import Swal from "sweetalert2";
import {useState} from "react";

function App() {
  const [is_login, change_login] = useState(!!localStorage.getItem('login_token')); // login => true, signup => true
  return (
    <div className="App">
        {is_login?<Main />:<Login_signup />}
    </div>
  );
}

export default App;
